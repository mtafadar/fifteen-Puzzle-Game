import java.util.ArrayList;
import java.util.concurrent.Callable;

public class A_IDS_A_15solver {
	
	/*
	 * @author Mark Hallenbeck
	 * Copyright© 2014, Mark Hallenbeck, All Rights Reservered.
	 * modified by Mosrour
	 */
	 ArrayList<Node> solutionpath;

public A_IDS_A_15solver(String heuristic, int[] gameBoard){  
		Node startState = new Node(gameBoard);
		startState.setDepth(0);
		if(heuristic.equals("heuristicOne")) {
		System.out.println("\nStarting A* Search with heuristic #1....This may take a while\n\n");
		A_Star(startState, "heuristicOne");
		
		} else {
			System.out.println("\nStarting A* Search with heuristic #2....This may take a while\n\n");
			A_Star(startState, "heuristicTwo");
		}
		System.out.println("\nThanks for using me to solve your 15 puzzle......Goodbye");

	}

/**
 * Method takes node with the start state as well as which heuristic to use and initializes a DB_Solver2 object(A* search).
 * It then solves the puzzle and prints out some metadata and the solution path
 * @param startState
 * @param heuristic
 */
	public void A_Star(Node startState, String heuristic){
		
				
		DB_Solver2 start_A_Star = new DB_Solver2(startState, heuristic);
		
				
		Long start = System.currentTimeMillis();

		Node solution = start_A_Star.findSolutionPath();	
		
		Long end = System.currentTimeMillis();

		System.out.println("\n******Run Time for A* "+ heuristic + " is: "+ (end-start) + " milliseconds**********");
		
		if(solution == null)							
		{
			System.out.println("\nThere did not exist a solution to your puzzle with A* search\n");
		}
		else										
		{
			solutionpath = start_A_Star.getSolutionPath(solution);	
		}	
	}
	
	public void printSolution(ArrayList<Node> path){
	
		System.out.print("\n\n");
		
		System.out.println("**************Initial State******************");
		for(int i=0; i<path.size(); i++){
			
			printState(path.get(i));
			
			if(i != (path.size() - 1))
				System.out.print("\nNext State => "+i+"\n\n");
			
		}
		System.out.println("\n**************Goal state****************");
	}

	public void printState(Node node){
	
		int[] puzzleArray = node.getKey();
		
		for(int i =0; i< puzzleArray.length; i++){
		
			System.out.printf("%4d ",puzzleArray[i]);
			if(i == 3 || i == 7 || i == 11)
				System.out.print("\n");
		}
	
}

}
