import java.util.ArrayList;
import java.util.concurrent.Callable;

public class MyCallable implements Callable<ArrayList<Node>>{
	int[] gameBoard;
	String myheuristic;
	int [] replicaboard;
	
	
	public MyCallable(String heuristic, int[] myboard) {
		gameBoard = myboard;	
		replicaboard = gameBoard;
		myheuristic = heuristic;
		
	}

	@Override
	public ArrayList<Node> call() throws Exception {

			A_IDS_A_15solver solve = new A_IDS_A_15solver(myheuristic, gameBoard);
			
		return solve.solutionpath;
	}
}
