

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;



import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.Pair;

public class JavaFXTemplate extends Application {
	
	
	//testing
	GameLogic gameLogic = new GameLogic();
	ArrayList < Node > solutionPath;
	
	/*
	 Data members
	 */
	HashMap<String, Scene> sceneMap;
	Button heuristicOne;
	Button heuristicTwo;
	Button solBtn;
	Button newGame;
	Button exitGame;
	Button infoGame;
	Button newGame1;
	Button exitGame1;
	Button backBtn;
	/*For scene*/
	Stage PrimaryStage;
	/* Create Grid */
	GridPane grid;
	
	GameButton emptyButton;
	
	LinkedHashMap < Pair < Integer, Integer>, GameButton> gameBoard = new LinkedHashMap<>();
	
	// for style
	private static final String HOVERED_BUTTON_STYLE = "-fx-background-color: #FFE184; -fx-font-weight: bold;";
	private static final String IDLE_BUTTON_STYLE = "-fx-background-color: #DCDCDC; -fx-font-weight: bold;";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
		
	}
	
	public void styleButtons() {
		heuristicOne.prefWidth(280);
		heuristicOne.setPrefHeight(40);
		heuristicOne.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		heuristicOne.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px;-fx-text-fill: 3B1F40;");
		
		heuristicTwo.prefWidth(280);
		heuristicTwo.setPrefHeight(40);
		heuristicTwo.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		heuristicTwo.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		solBtn.prefWidth(280);
		solBtn.setPrefHeight(40);
		solBtn.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		solBtn.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		newGame.prefWidth(280);
		newGame.setPrefHeight(40);
		newGame.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		newGame.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		exitGame.prefWidth(280);
		exitGame.setPrefHeight(40);
		exitGame.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		exitGame.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		infoGame.prefWidth(280);
		infoGame.setPrefHeight(40);
		infoGame.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		infoGame.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		newGame1.prefWidth(280);
		newGame1.setPrefHeight(40);
		newGame1.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		newGame1.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		exitGame1.prefWidth(280);
		exitGame1.setPrefHeight(40);
		exitGame1.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		exitGame1.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
		
		backBtn.prefWidth(280);
		backBtn.setPrefHeight(40);
		backBtn.setFont(Font.font ("Times New Roman", FontWeight.BOLD, 20));
		backBtn.setStyle("-fx-background-color: #9EC1C4; -fx-border-width: 2px; -fx-text-fill: 3B1F40;");
	}
	

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to 15 Puzzle Game");
		this.PrimaryStage = primaryStage;
		
		ArrayList<Integer> temp = new ArrayList<>();
		
		temp = gameLogic.getPuzzle();
		
		for (int i : temp) {
			System.out.print(i + ", ");
		}
		System.out.println();
		
		/*
		 * Declaring data members
		 * */
		sceneMap = new HashMap<String, Scene>();
		heuristicOne = new Button("AI H1 Solution");
		heuristicTwo = new Button("AI H2 Solution");
		solBtn = new Button("Click to see Solution");
		newGame = new Button("New Game");
		exitGame = new Button("Exit Game");
		infoGame = new Button("How to play");
		newGame1 = new Button("New Game");
		exitGame1 = new Button("Exit Game");
		backBtn = new Button("Go Back");
		grid = new GridPane();
		/*
		 * Style buttons
		 * */
		
		styleButtons();
		sceneMap.put("welcomeScene", createWelcomeScene());
		createGameScene();
		sceneMap.put("resultScene", createResultsScene());
		sceneMap.put("infoScene", createInfoScene());
		/*
		 * Defining actions
		 * */
		infoGame.setOnAction( e ->{
			 primaryStage.setScene(sceneMap.get("infoScene"));
		 });
		
		backBtn.setOnAction( e ->{
			 primaryStage.setScene(sceneMap.get("gameBoardScene"));
		 });
		
		exitGame.setOnAction( e ->{
			 System.exit(0);
		 });
		
		exitGame1.setOnAction( e ->{
			 System.exit(0);
		 });
		
		newGame.setOnAction(new EventHandler < ActionEvent > () {
		      public void handle(ActionEvent a) {
		    	  grid.getChildren().clear();
		    	  gameLogic.reset();
		    	  gameBoard.clear();
		    	  createGameScene();
		    	  primaryStage.setScene(sceneMap.get("gameBoardScene"));
		      }
		});
		
		newGame1.setOnAction(new EventHandler < ActionEvent > () {
		      public void handle(ActionEvent a) {
		    	  grid.getChildren().clear();
		    	  gameLogic.reset();
		    	  gameBoard.clear();
		    	  createGameScene();
		    	  primaryStage.setScene(sceneMap.get("gameBoardScene"));
		      }
		});
				
		
		this.PrimaryStage.setScene(sceneMap.get("welcomeScene"));
		PauseTransition pause = new PauseTransition(Duration.seconds(4));
	    pause.setOnFinished(e -> this.PrimaryStage.setScene(sceneMap.get("gameBoardScene")));
	    pause.play();
		this.PrimaryStage.show();

	}

	private Scene createInfoScene() {
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-font-family: serif;");
		pane.setPadding(new Insets(100));
		
		Image img1 = new Image("infoScreen.png");
		BackgroundSize bSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true);
        pane.setBackground(new Background(new BackgroundImage(img1, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,BackgroundPosition.CENTER,bSize)));
	
        HBox otherBtns = new HBox(backBtn);
        otherBtns.setAlignment(Pos.CENTER);
    
        pane.setBottom(otherBtns);
        
		return new Scene(pane, 900, 800);
	}

	private Scene createResultsScene() {
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-font-family: serif;");
		pane.setPadding(new Insets(100));
		
		Image img1 = new Image("winScreen.png");
		BackgroundSize bSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true);
        pane.setBackground(new Background(new BackgroundImage(img1, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,BackgroundPosition.CENTER,bSize)));
	

        HBox otherBtns = new HBox(newGame1, exitGame1);
        otherBtns.setSpacing(8);
        otherBtns.setAlignment(Pos.CENTER);
    
        pane.setBottom(otherBtns);
		return new Scene(pane, 900, 800);
	}

	private void createGameScene() {
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-font-family: serif;");
		pane.setPadding(new Insets(100));
		
		grid.setMaxHeight(550);
		
		Image img1 = new Image("board.png");
		BackgroundSize bSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true);
        pane.setBackground(new Background(new BackgroundImage(img1, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,BackgroundPosition.CENTER,bSize)));
        
        
        HBox HeuristicsBtns = new HBox(heuristicOne, heuristicTwo);
        HeuristicsBtns.setSpacing(8);

        HBox topBox = new HBox(HeuristicsBtns, solBtn);
        topBox.setAlignment(Pos.CENTER);
        topBox.setSpacing(16);
        solBtn.setDisable(true);

        HBox otherBtns = new HBox(newGame, infoGame);
        otherBtns.setSpacing(8);
        
      
        
        HBox bottomBox = new HBox(otherBtns, exitGame);
        bottomBox.setAlignment(Pos.CENTER);
        bottomBox.setSpacing(16);
        
        // Initially set the solution button disabled
        solBtn.setDisable(true);
        
        // action for the heuristic buttons
        heuristicOne.setOnAction(new EventHandler < ActionEvent > () {
            public void handle(ActionEvent a) {
//            	System.out.println("Im in heauristic One action");
            	generatingThreadPath("heuristicOne");
            }
          });

        heuristicTwo.setOnAction(new EventHandler < ActionEvent > () {
            public void handle(ActionEvent a) {
            	generatingThreadPath("heuristicTwo");
            }
          });

        
        // check for the solution for the heuristic buttons :
        // its in case the button is clicked
        solBtn.setOnAction(new EventHandler < ActionEvent > () {
            public void handle(ActionEvent a) {
            	
                int boundLimit = 10;
                int length = solutionPath.size();
            	
            	// since finding solution so disable all the gameBoard buttons
            	for(GameButton btn : gameBoard.values()) {
            		btn.setDisable(true);
            	}
            	heuristicOne.setDisable(true);
            	heuristicTwo.setDisable(true);
            	
               // check how many moves are remaining so as to calculate solution
               if (length <= 10) {
                   boundLimit = solutionPath.size() - 1;
               }
               
               // check for the winner in case doing the moves
               for(int i = 1; i <= boundLimit; i++) {
                   int counter = i;
                   PauseTransition pause = new PauseTransition(Duration.seconds(counter + 1));
                   pause.play();
                   // while checking for solution:
                   pause.setOnFinished(b -> {
                     //	get the current puzzle moves already made to check solution moves 					
                     int[] puzzle = solutionPath.get(counter).getKey();
                     int X1 = -1;
                     int Y1 = -1;
                     int X2 = 4;
                     int Y2 = 4;
                     
                     // start process for swapping if there is empty spot then swap it 
                     for(int j = 0; j <16; j++) {
                    	if (puzzle[j] == 0) {
                             X1 = j / X2;
                             Y1 = j % Y2;
                          }
                     }
                     swapingTheBox(gameBoard.get(new Pair<> (X1, Y1)));
                     
                     // check if the puzzle is solved 
                     if (gameLogic.WinnerCheck() == true) {
                       PauseTransition Pause = new PauseTransition(Duration.seconds(3));
                       Pause.setOnFinished(d -> PrimaryStage.setScene(sceneMap.get("resultScene")));
                       Pause.play();
                     }
                   });
                 }
               // there is no winner and solution is available enable buttons
               solBtn.setDisable(true);
               PauseTransition pauseOne = new PauseTransition(Duration.seconds(boundLimit + 3));
               pauseOne.setOnFinished(b -> {
            	 heuristicOne.setDisable(false);
            	 heuristicTwo.setDisable(false);

                 for (GameButton btn: gameBoard.values()) {
                   btn.setDisable(false);
                 }
               });
               pauseOne.play();
            }
          });
        
        
        // get 1 puzzle from game logic class
        ArrayList <Integer> RandomList =  gameLogic.getPuzzle();
        
        int i = 0;
        int colomVal = 0;
        int rowVal = 0;
        int totalRows  = 4;
        int totalColom = 4;
        while(rowVal < totalRows) {
        	colomVal = 0;
        	while(colomVal < totalColom) {
        		if(RandomList.get(i) == 0) {
        			emptyButton = new GameButton(rowVal, colomVal, 0);
        			emptyButton.setMaxSize(100,100);
        			emptyButton.setMinSize(100,100);
        			emptyButton.setFocusTraversable(false);
        			emptyButton .setOpacity(0.5);
        			emptyButton.setVisible(false);
        			gameBoard.put(new Pair < > (rowVal, colomVal), emptyButton);
        	        gameLogic.gameBoard.put(new Pair<>(rowVal, colomVal), 0);
        		    grid.add(emptyButton , colomVal, rowVal);
        		    
        		}
        		else {
        			GameButton otherButton = new GameButton(rowVal, colomVal, RandomList.get(i));
        			otherButton.setOnMouseEntered(e -> otherButton.setStyle(HOVERED_BUTTON_STYLE));
        			otherButton.setOnMouseExited(e -> otherButton.setStyle(IDLE_BUTTON_STYLE));
        			
        			// action for the button clicked
        			// action for when clicked on empty box
        			otherButton.setOnAction(new EventHandler <ActionEvent>() {
        				public void handle(ActionEvent c) {
        					// get the source from the button being clicked initially
        					GameButton clickBtn = (GameButton) c.getSource();
        					if (gameLogic.checkingNearby(clickBtn.Xside, clickBtn.Yside, new Pair < Integer, Integer > (emptyButton.Xside, emptyButton.Yside))) {
        						swapingTheBox(clickBtn);
        					}
        					
        					// check if the puzzle is solved so win
        					if (gameLogic.WinnerCheck()) {
        						PauseTransition p1 = new PauseTransition(Duration.seconds(3));
        		                p1.setOnFinished(e -> PrimaryStage.setScene(sceneMap.get("resultScene")));
        		                p1.play();
        					}
        				}
        			});
        			
        			otherButton.setMaxSize(100,100);
        			otherButton.setMinSize(100,100);
        			otherButton.setFocusTraversable(false);
        			otherButton.setOpacity(0.5);
        			gameBoard.put(new Pair < > (rowVal, colomVal), otherButton);
        			gameLogic.gameBoard.put(new Pair<>(rowVal, colomVal), otherButton.value);
        			grid.add(otherButton, colomVal, rowVal);
        		}
        		i++;
        		colomVal++;
        		
        	}
        	rowVal++;
        }
        grid.setMaxHeight(480);
        grid.setMaxWidth(500);
        grid.setMinWidth(500);
        grid.setMinHeight(480);
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setStyle("-fx-background-color: black;");
      
        pane.setTop(topBox);
        pane.setCenter(grid);
        grid.setAlignment(Pos.CENTER);
        pane.setBottom(bottomBox);
		
		Scene gameScene = new Scene(pane, 900, 800);
	    sceneMap.put("gameBoardScene", gameScene);
	}

	private Scene createWelcomeScene() {
		BorderPane pane = new BorderPane();
		pane.setStyle("-fx-font-family: serif;");
		pane.setPadding(new Insets(100));
		Image img1 = new Image("welcom.png");
		BackgroundSize bSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true);
        pane.setBackground(new Background(new BackgroundImage(img1, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT,BackgroundPosition.CENTER,bSize)));
		return new Scene(pane, 900, 800);
	}	
	//during thread we need to copy the array
	public int[] copyingTheArrayThread() {
	       
		int[] tempArray  = new int[16];
		Object[] currBoardArray = gameLogic.gameBoard.values().toArray();
		for(int i = 0; i < 16; i++) {
			tempArray [i] = (int)currBoardArray[i];
		}
		return tempArray;
	}
	public void swapingTheBox(GameButton mvBtn) {
		
		// show swap on gridpane
		GridPane.setRowIndex(mvBtn, emptyButton.Xside);
	    GridPane.setRowIndex(emptyButton, mvBtn.Xside);
	    GridPane.setColumnIndex(mvBtn, emptyButton.Yside);
	    GridPane.setColumnIndex(emptyButton, mvBtn.Yside);
		int sideX = mvBtn.Xside;
		int sideY = mvBtn.Yside;
		
		// now I will swap the  place, swaps the button clicked
		mvBtn.Xside = emptyButton.Xside;
		mvBtn.Yside = emptyButton.Yside;
		// swap empty box
		emptyButton.Xside = sideX;
		emptyButton.Yside = sideY;
		
		gameBoard.replace(new Pair<Integer, Integer> (mvBtn.Xside, mvBtn.Yside), emptyButton, mvBtn);
		gameBoard.replace(new Pair<>(sideX, sideY), mvBtn, emptyButton);
		
		gameLogic.gameBoard.replace(new Pair<Integer, Integer>(mvBtn.Xside, mvBtn.Yside), mvBtn.value);
		gameLogic.gameBoard.replace(new Pair<>(sideX, sideY), 0);
	}
	
	public void generatingThreadPath(String heurVal) {
//		System.out.println("Im in generate thread ");
		
		Thread thread = new Thread(()->{
			ExecutorService excutor = Executors.newFixedThreadPool(10);
			int[] firstArray = copyingTheArrayThread();
			Future<ArrayList<Node>> future = excutor.submit(new MyCallable(heurVal, firstArray));
			
			 try {
			    	// we will get the result so will have to wait some time until we get result
				 	// and not have the application thread stuck
//				    System.out.println("Im in try thread part One ");
				    solutionPath = future.get(90000, TimeUnit.MILLISECONDS);
				    int length = solutionPath.size();
				    System.out.println("Generated Path Size:" + " " + length);
				    solBtn.setDisable(false);
			      } catch (Exception err) {
			        System.out.println(err.getMessage());
			        future.cancel(true);
			        solBtn.setDisable(true);
			      }
			      excutor.shutdown();
		});
		thread.start();
		solBtn.setDisable(true);
	}
	
	public void getNewPuzzle() {
		grid.getChildren().clear();
		gameLogic.reset();
		// create new game
		gameBoard.clear();
		createGameScene();
		// show it on the screen
		PrimaryStage.setScene(sceneMap.get("gameBoardScene"));
	}	
}
