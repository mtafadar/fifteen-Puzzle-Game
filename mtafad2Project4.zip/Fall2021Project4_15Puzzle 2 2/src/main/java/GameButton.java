
import javafx.scene.control.Button;

public class GameButton extends Button {
	
	public int Xside, Yside, value, moveOccur; 
	private int chkButton;
	
	
	public GameButton(int xval, int yval,  int val) {
		value = val; // this gives us the actual value
		Xside = xval;  
		Yside = yval;
		moveOccur = -1; // total number of mode made;
		chkButton  = 0;
		setText(String.valueOf(value));
	}
	public int getXval() {
		return this.Xside;
	}
	
	public int  getYval() {
		return this.Yside;
	}
	
	public int getchkButton() {
		return this.chkButton;
	}
	
	public int getMovOccur() {
		return this.moveOccur;
	}
	
	public void setXval(int val) {
		this.Xside =  val;
	}
	
	public void setYval(int val) {
		this.Yside = val;
	}
	
	public void setchkButton(int val) {
		this.chkButton = val;
	}
	
	public void setMovOccur(int val) {
		this.moveOccur = val;
	}
}