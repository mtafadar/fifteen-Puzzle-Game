import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import javafx.util.Pair;

public class GameLogic {
	
	/*
	 * We need 10 puzzles so 10 array List
//	 * */
	ArrayList<Integer> puzzle1;
	ArrayList<Integer> puzzle2;
	ArrayList<Integer> puzzle3;
	ArrayList<Integer> puzzle4;
	ArrayList<Integer> puzzle5;
	ArrayList<Integer> puzzle6;
	ArrayList<Integer> puzzle7;
	ArrayList<Integer> puzzle8;
	ArrayList<Integer> puzzle9;
	ArrayList<Integer> puzzle10;
	ArrayList<Integer> answersArray;
	ArrayList<Integer> puzzlesSelected; 
	
	HashMap<Integer, ArrayList<Integer>> allPuzzles = new HashMap<Integer, ArrayList<Integer>>();
	LinkedHashMap<Pair<Integer,Integer>, Integer> gameBoard = new LinkedHashMap<>();
	int count ;
	
	/*
	 * Constructor
	 * */
	GameLogic() {
		puzzle1 = new ArrayList<>();
		puzzle2 = new ArrayList<>();
		puzzle3 = new ArrayList<>();
		puzzle4 = new ArrayList<>();
		puzzle5 = new ArrayList<>();
		puzzle6 = new ArrayList<>();
		puzzle7 = new ArrayList<>();
		puzzle8 = new ArrayList<>();
		puzzle9 = new ArrayList<>();
		puzzle10 = new ArrayList<>();
		answersArray = new ArrayList<>();
		puzzlesSelected = new ArrayList<>();
		count = 0;
		
		addPuzzle1();
		addPuzzle2();
		addPuzzle3();
		addPuzzle4();
		addPuzzle5();
		addPuzzle6();
		addPuzzle7();
		addPuzzle8();
		addPuzzle9();
		addPuzzle10();
		
		for(int i = 0; i < 16; i++) {
			answersArray.add(i);
		}
		/*
		 * Initially no puzzle is selected so the values are all 0
		 *  when puzzle is selected make it 1
		 * */
		
		for(int i = 0; i < 10; i++) {
			puzzlesSelected.add(0);
		}
	}



	
	
	// The function returns one puzzle from allPuzzle hashmap 
	
	public ArrayList<Integer> getPuzzle() {
		addAllPuzzles();
		
		// temp array list to hold the puzzle in the end to return
		ArrayList<Integer> tempResult = new ArrayList<>();
		// Arraylist to hold 0-10 puzzle and get random puzzle from it and shuffle array
		ArrayList<Integer> randmNums = new ArrayList<>();
		
		
		// Adding 10 numbers to array
		for(int i = 0; i < 10; i++) {
			randmNums.add(i);
		}
		// Randomizing the RandomNums
		Collections.shuffle(randmNums);
		System.out.println("Random Puzzle " +randmNums);
		
		
		int rand = 0;
		int numSelected = randmNums.get(rand);
		
		
		
		// check the puzzlesSelected array if the puzzle is already selected then increment count
		for (int i = 0; i < 10; i++) {
			if (puzzlesSelected.get(i) == 1) {
				count++;
			}
		}

		
		// Counter to keep track of the number of puzzles used
		// if counter is 10 means we have selected or played all the puzzles
		if (count  == 10) {
			
			for (int i = 0; i < 10; i++) {
				puzzlesSelected.set(i, 0);
			}
		}
		
		// [1, 8, 4, 6, 2, 3, 5, 9, 7, 0]
		
		// check if the puzzle is already selected
	    while(puzzlesSelected.get(numSelected) == 1) {
	    	rand++;
		   numSelected = randmNums.get(rand);
		   if(rand == 9) {
			   break;
		   }
	    }
		
		// as puzzle is selected now so mark it selected in the puzzlesSelected array
		puzzlesSelected.set(numSelected, 1);
		
		// prepare for returning the puzzle we have got
		tempResult = allPuzzles.get(numSelected);
		
		return tempResult;
	}
	
	// The function add 10 puzzles to one hashmap
	
	public void addAllPuzzles() {
		allPuzzles.put(0, puzzle1);
		allPuzzles.put(1, puzzle2);
		allPuzzles.put(2, puzzle3);
		allPuzzles.put(3, puzzle4);
		allPuzzles.put(4, puzzle5);
		allPuzzles.put(5, puzzle6);
		allPuzzles.put(6, puzzle7);
		allPuzzles.put(7, puzzle8);
		allPuzzles.put(8, puzzle9);
		allPuzzles.put(9, puzzle10);
	}
	
	
	public Boolean WinnerCheck() {
		Boolean ans;
		if(Arrays.equals(answersArray.toArray(), gameBoard.values().toArray())) {
			ans = true;
			return ans;
		}
		return false;
	}
	
	
	public Boolean checkingNearby(int xSide, int ySide, Pair<Integer, Integer> OpenSpace) {
		
		// keep check on if there is open space available near by
		Boolean moveAble = false;
		
		// Hashmap consist of surrending
		HashMap<String, Integer> checkNear = new HashMap<String, Integer>();
		
		
		checkNear.put("down", 1);
		checkNear.put("up", 1);
		checkNear.put("right", 1);
		checkNear.put("left", 1);
		
		Set<Pair <Integer, Integer>> nearby = new LinkedHashSet<>();
		
		nearby.add(new Pair<Integer, Integer>(xSide+checkNear.get("right"), ySide));
		nearby.add(new Pair<Integer, Integer>(xSide-checkNear.get("left"), ySide));
		nearby.add(new Pair<Integer, Integer>(xSide, ySide + checkNear.get("up")));
		nearby.add(new Pair<Integer, Integer>(xSide, ySide-checkNear.get("down")));
		
		if(nearby.contains(OpenSpace)) {
			moveAble = true;
			return moveAble;
		}
		return moveAble;
		
	}
	
	
	public void reset() {
		gameBoard.clear();
		
	}
	
	
	//good
	public void addPuzzle1() {
		puzzle1.add(4);
		puzzle1.add(11);
		puzzle1.add(2);
		puzzle1.add(3);
		puzzle1.add(1);
		puzzle1.add(6);
		puzzle1.add(7);
		puzzle1.add(0);
		puzzle1.add(9);
		puzzle1.add(5);
		puzzle1.add(10);
		puzzle1.add(8);
		puzzle1.add(12);
		puzzle1.add(13);
		puzzle1.add(14);
		puzzle1.add(15);
		
	}
	//good
	public void addPuzzle2() {
		puzzle2.add(1);
		puzzle2.add(2);
		puzzle2.add(3);
		puzzle2.add(0);
		puzzle2.add(11);
		puzzle2.add(4);
		puzzle2.add(9);
		puzzle2.add(5);
		puzzle2.add(8);
		puzzle2.add(10);
		puzzle2.add(7);
		puzzle2.add(6);
		puzzle2.add(12);
		puzzle2.add(13);
		puzzle2.add(14);
		puzzle2.add(15);
		
	}
	
	//goood
	public void addPuzzle3() {
		puzzle3.add(1);
		puzzle3.add(9);
		puzzle3.add(6);
		puzzle3.add(3);
		puzzle3.add(4);
		puzzle3.add(0);
		puzzle3.add(2);
		puzzle3.add(7);
		puzzle3.add(8);
		puzzle3.add(5);
		puzzle3.add(10);
		puzzle3.add(11);
		puzzle3.add(12);
		puzzle3.add(13);
		puzzle3.add(14);
		puzzle3.add(15);
	}
	
	//good
	public void addPuzzle4() {
		
		puzzle4.add(4);
		puzzle4.add(1);
		puzzle4.add(0);
		puzzle4.add(3);
		puzzle4.add(5);
		puzzle4.add(2);
		puzzle4.add(10);
		puzzle4.add(7);
		puzzle4.add(8);
		puzzle4.add(9);
		puzzle4.add(6);
		puzzle4.add(11);
		puzzle4.add(12);
		puzzle4.add(13);
		puzzle4.add(14);
		puzzle4.add(15);
		
	}
	
	//good
	public void addPuzzle5() {
		puzzle5.add(4);
		puzzle5.add(2);
		puzzle5.add(0);
		puzzle5.add(3);
		puzzle5.add(5);
		puzzle5.add(11);
		puzzle5.add(1);
		puzzle5.add(7);
		puzzle5.add(8);
		puzzle5.add(9);
		puzzle5.add(10);
		puzzle5.add(6);
		puzzle5.add(12);
		puzzle5.add(13);
		puzzle5.add(14);
		puzzle5.add(15);
		
	}
	
	public void addPuzzle6() {
		
		puzzle6.add(2);
		puzzle6.add(0);
		puzzle6.add(1);
		puzzle6.add(3);
		puzzle6.add(4);
		puzzle6.add(5);
		puzzle6.add(11);
		puzzle6.add(7);
		puzzle6.add(8);
		puzzle6.add(9);
		puzzle6.add(10);
		puzzle6.add(6);
		puzzle6.add(12);
		puzzle6.add(13);
		puzzle6.add(14);
		puzzle6.add(15);
		
	}
	
	public void addPuzzle7() {
		puzzle7.add(4);
		puzzle7.add(1);
		puzzle7.add(6);
		puzzle7.add(3);
		puzzle7.add(9);
		puzzle7.add(0);
		puzzle7.add(2);
		puzzle7.add(7);
		puzzle7.add(8);
		puzzle7.add(5);
		puzzle7.add(10);
		puzzle7.add(11);
		puzzle7.add(12);
		puzzle7.add(13);
		puzzle7.add(14);
		puzzle7.add(15);
		
	}
	
	public void addPuzzle8() {
		
		puzzle8.add(2);
		puzzle8.add(1);
		puzzle8.add(6);
		puzzle8.add(3);
		puzzle8.add(4);
		puzzle8.add(0);
		puzzle8.add(9);
		puzzle8.add(7);
		puzzle8.add(8);
		puzzle8.add(5);
		puzzle8.add(10);
		puzzle8.add(11);
		puzzle8.add(12);
		puzzle8.add(13);
		puzzle8.add(14);
		puzzle8.add(15);
		
	}
	
	public void addPuzzle9() {
		puzzle9.add(11);
		puzzle9.add(1);
		puzzle9.add(9);
		puzzle9.add(3);
		puzzle9.add(4);
		puzzle9.add(5);
		puzzle9.add(1);
		puzzle9.add(7);
		puzzle9.add(8);
		puzzle9.add(10);
		puzzle9.add(0);
		puzzle9.add(6);
		puzzle9.add(12);
		puzzle9.add(13);
		puzzle9.add(14);
		puzzle9.add(15);
		
	}
	public void addPuzzle10() {
		puzzle10.add(11);
		puzzle10.add(1);
		puzzle10.add(2);
		puzzle10.add(3);
		puzzle10.add(5);
		puzzle10.add(0);
		puzzle10.add(8);
		puzzle10.add(6);
		puzzle10.add(4);
		puzzle10.add(9);
		puzzle10.add(10);
		puzzle10.add(7);
		puzzle10.add(12);
		puzzle10.add(13);
		puzzle10.add(14);
		puzzle10.add(15);
	}
	
}
