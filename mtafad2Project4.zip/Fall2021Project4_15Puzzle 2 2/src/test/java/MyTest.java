import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {
	
	/*
	 * In this class I am going to test all  my  puzzle to see whether those solveable or no
	 */
	int[]puzzle1 =  {4,11,2,3,1,6,7,0,9,5,10,8,12,13,14,15};
	int[] puzzle2=  {1,2,3,0,11,4,9,5,8,10,7,6,12,13,14,15};
    int [] puzzle3 ={1,9,6,3,4,0,2,7,8,5,10, 11,12, 13,14,15};
	int[] puzzle4 = {4,1,0,3,5, 2,10,7,8,9, 6,11,12,13,14,15};
	int[] puzzle5 = {4,2,0,3,5,11,1,7,8,9,10,6,12,13,14,15};
	int []puzzle6 = {2,0,1,3,4,5,11,7,8,9,10,6,12,13,14,15};
	int [] puzzle7 = {4,1,6,3,9,0,2,7,8,5,10,11,12,13,14,15};
	int [] puzzle8 = {2,1,6,3,4,0,9,7,8,5,10,11,12,13,14,15};
	int[] puzzle9 = {11,1,9,3,4,5,1,7,8,10,0,6,12,13,14,15};
	int [] puzzle10 = {11,1,2,3,5,0,8,6,4,9,10,7,12,13,14,15};
	int [] tempA = {};
	Node  temp;
	DB_Solver2  temp1;
	
	
	
	

	@Test
	void test() {
		 temp = new Node(puzzle1);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle1));
		System.out.println("The length of puzzle1 is: " + puzzle1.length);
		assertEquals(1, solveable.size(), "not solveable");
	}
	
	@Test
	void test2() {
		 temp = new Node(puzzle1);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle1));
		assertEquals(1, solveable.size(), "not solveable");
	}
	
	@Test
	void test3() {
		 temp = new Node(puzzle2);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle2));
		System.out.println("The length of puzzle2 is: " + puzzle2.length);
		assertEquals(1, solveable.size(), "not solveable");
	}
	
	@Test
	void test4() {
		 temp = new Node(puzzle2);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle2));
		assertEquals(1, solveable.size(), "not solveable");
	}
	
	@Test
	void test5() {
		 temp = new Node(puzzle3);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle3 is: " + puzzle3.length);
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle3));
		assertEquals(1, solveable.size(), "not solveable");
	}
	
	@Test
	void test6() {
		 temp = new Node(puzzle3);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable= temp1.getSolutionPath(new Node(puzzle3));
		assertEquals(1, solveable.size(), "Not solveable");
	}
	
	@Test
	void test7() {
		 temp = new Node(puzzle4);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle4 is: " + puzzle4.length);
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle4));
		assertEquals(1, solveable.size(), "Not solveable");
	}
	
	@Test
	void test8() {
		 temp = new Node(puzzle4);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable= temp1.getSolutionPath(new Node(puzzle4));
		assertEquals(1, solveable.size(), "not soveable");
	}
	
	@Test
	void test9() {
		 temp = new Node(puzzle5);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle5 is: " + puzzle5.length);
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle5));
		assertEquals(1, solveable.size(), "Not solveable");
	}
	
	@Test
	void test10() {
		 temp = new Node(puzzle5);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle5));
		assertEquals(1, solveable.size(), "Not solveable");
	}
	
	
	
	@Test
	void test11() {
		 temp = new Node(puzzle6);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle6 is: " + puzzle6.length);
		ArrayList<Node> solveable= temp1.getSolutionPath(new Node(puzzle6));
		assertEquals(1, solveable.size(), "Not solveable");
	}
	
	@Test
	void test12() {
		 temp = new Node(puzzle6);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable= temp1.getSolutionPath(new Node(puzzle6));
		assertEquals(1, solveable.size(), "not solveable");
	}
	
	@Test
	void test13() {
		 temp = new Node(puzzle7);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle7 is: " + puzzle7.length);
		ArrayList<Node> solveable= temp1.getSolutionPath(new Node(puzzle7));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	
	@Test
	void test14() {
		 temp = new Node(puzzle7);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle7));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	@Test
	void test15() {
		 temp = new Node(puzzle8);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle8 is: " + puzzle8.length);
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle8));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	
	@Test
	void test16() {
		 temp = new Node(puzzle8);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle8));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	
	@Test
	void test17() {
		 temp = new Node(puzzle9);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle9 is: " + puzzle9.length);
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle9));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	
	@Test
	void test18() {
		 temp = new Node(puzzle9);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle9));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	
	@Test
	void test19() {
		 temp = new Node(puzzle10);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicOne");
		System.out.println("The length of puzzle10 is: " + puzzle10.length);
		ArrayList<Node> solveable= temp1.getSolutionPath(new Node(puzzle9));
		assertEquals(1, solveable.size(), "not Solveable");
	}
	
	@Test
	void test20() {
		 temp = new Node(puzzle10);
		temp.setDepth(0);
		temp1 = new DB_Solver2(temp, "heuristicTwo");
		ArrayList<Node> solveable = temp1.getSolutionPath(new Node(puzzle10));
		assertEquals(1, solveable.size(), "not Solveable");
	}

}
